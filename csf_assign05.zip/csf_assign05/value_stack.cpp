#include "value_stack.h"
#include "exceptions.h"

ValueStack::ValueStack()
  // TODO: initialize member variable(s) (if necessary)
{
}

ValueStack::~ValueStack()
{
}

bool ValueStack::is_empty() const
{
  // TODO: implement
}

void ValueStack::push( const std::string &value )
{
  // TODO: implement
}

std::string ValueStack::get_top() const
{
  // TODO: implement
}

void ValueStack::pop()
{
  // TODO: implement
}
