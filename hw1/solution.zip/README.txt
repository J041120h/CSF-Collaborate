Haojun Shi, hshi33
Hua Jiang, hjiang55

We collaborate on the homework. Before the ddl of MS1, we almost finish both MS1 and MS2. Both member independently finish implementation
of MS1. Haojun Shi finish private helper function of adding and subtracting magnitudes, and also divide by 2, and implementation of leftshift and is_bit_set.
Hua Jiang finish implementation of mutiplication, division, and to decimal. We write test cases together after finishing respectively
