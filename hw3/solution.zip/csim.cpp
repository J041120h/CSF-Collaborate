#include "csim.h"
#include <cstdint>
#include <iostream>
#include <cstdint>
#include <vector>

bool check_two_power(int n) {
    while(n != 1) {
        if(n % 2 != 0) {
            return false;
        }
        n = n / 2;
    }
    return true;
}

void load(Cache &cache, uint32_t address, std::string replaceApproach) {
    //parse
    std::pair<uint32_t, uint32_t> parResult;
    parResult = parse(cache, address);
    Set& currentSet = cache.sets[parResult.second];
    bool hitStatus = checkHit(cache, parResult.second, parResult.first);
    if (hitStatus) {
        //if hit, update time
        cache.totalCycle += 1;
        cache.loadHit++;
    } else {
        uint32_t setStatus = checkSlotAvailability(currentSet);
        if (setStatus != uint32_t(-1)) {
            //If there's still space availble in current set
            Slot input = Slot{parResult.first, true, cache.totalCycle,cache.totalCycle, false};
            currentSet.slots[setStatus] = input;
        } else {
            if (replaceApproach == "fifo") {
                fifo(cache, currentSet, parResult.first);
            } else {
                lru(cache, currentSet, parResult.first);
            }
        }
        cache.totalCycle += cache.sizeSlot*25;
        cache.loadMiss ++;
    }
    cache.loadCount++;
}

void store(Cache &cache, uint32_t address, std::string loadMain, std::string storemain, std::string replaceApproach) {
    std::pair<uint32_t, uint32_t> parResult;
    parResult = parse(cache, address);
    Set& currentSet = cache.sets[parResult.second];
    bool hitStatus = checkHit(cache, parResult.second, parResult.first);
    if (hitStatus) {
        uint32_t index = 0;
        for (uint32_t i = 0; i < currentSet.maxSlots; i++) {
            if (currentSet.slots[i].tag == parResult.first) {
                index = i;
            }
        }
        if (loadMain == "write through") {
            writeThrough(cache, cache.sets[parResult.second], index);
        } else {
            writeBack(cache, cache.sets[parResult.second], index);
        }
        cache.storeHit++;
        cache.totalCycle += 1;
    } else {
        if (storemain == "no-write-allocate") {
            noWriteAllocate(cache);
        } else {
            writeAllocate(cache, replaceApproach, cache.sets[parResult.second], parResult.first);
        }
        cache.storeMiss++;
    }
    cache.storeCount++;
}

uint32_t get_two_power(uint32_t n) {
    uint32_t count = 0;
    while(n != 1) {
        n = n / 2;
        count ++;
    }
    return count;
}

std::pair<uint32_t, uint32_t> parse(Cache &cache, uint32_t address) {
    uint32_t num_bit_offset = get_two_power(cache.sizeSlot);
    uint32_t num_bit_index = get_two_power(cache.numSet);
    uint32_t tag = address >> (num_bit_offset + num_bit_index);
    uint32_t index = ( address >> (num_bit_offset) ) % (1 << num_bit_index);
    return std::make_pair(tag, index);
}

bool checkHit(Cache &cache, uint32_t index, uint32_t tag) {
    std::vector<Slot> slots = cache.sets[index].slots;
    for(std::vector<Slot>::iterator it = slots.begin(); it != slots.end(); it++) {
        if(it->valid) {
            if(it->tag == tag) {
                it->access_ts = cache.totalCycle;
                return true;
            }
        }
    }
    return false;
}

uint32_t checkSlotAvailability(Set &set) {
    for (uint32_t i = 0; i < set.maxSlots; i++) {
        if(!(set.slots[i].valid)) {
            return i;
        }
    }
    return -1;
}

uint32_t fifo(Cache &cache,  Set &set, uint32_t tag) {
    uint32_t index = 0;
    uint32_t oldest = set.slots[0].load_ts;
    for(uint32_t i =0 ; i < set.maxSlots; i ++) {
        if (set.slots[i].load_ts < oldest) {
            index = i;
            oldest = set.slots[i].load_ts;
        }
    }
    //discard the original node
    discard(cache, set.slots[index]);
    //update
    set.slots[index].tag = tag;
    set.slots[index].access_ts = cache.totalCycle;
    set.slots[index].load_ts = cache.totalCycle;
    return index;
}

uint32_t lru(Cache &cache, Set &set, uint32_t tag) {
    uint32_t index = 0;
    uint32_t oldest = set.slots[0].load_ts;
    for(uint32_t i =0 ; i < set.maxSlots; i ++) {
        if (set.slots[i].access_ts < oldest) {
            index = i;
            oldest = set.slots[i].access_ts;
        }
    }
    //discard the original node
    discard(cache, set.slots[index]);
    set.slots[index].tag = tag;
    set.slots[index].access_ts = cache.totalCycle;
    set.slots[index].load_ts = cache.totalCycle;
    return index;
}

void noWriteAllocate(Cache &cache) {
    cache.totalCycle += cache.sizeSlot/4*100;
}

void writeAllocate(Cache &cache, std::string replaceApproach, Set &set, uint32_t tag) {
    uint32_t index = -1;
    uint32_t setStatus = checkSlotAvailability(set);
    if (setStatus != uint32_t(-1)) {
        //If there's still space availble in current set
        Slot input = Slot{tag, true, cache.totalCycle,cache.totalCycle, true};
        set.slots[setStatus] = input;
    } else {
        if (replaceApproach == "fifo") {
            index = fifo(cache, set, tag);
        } else {
            index =lru(cache, set, tag);
        }
        set.slots[index].dirty = true;
    }
    cache.totalCycle += cache.sizeSlot/4*100 + 1;
}

void writeThrough(Cache &cache, Set &set, uint32_t index) {
    set.slots[index].access_ts = cache.totalCycle;
    cache.totalCycle += cache.sizeSlot/4*100;
}

void writeBack(Cache &cache, Set &set, uint32_t index) {
    set.slots[index].dirty = true;
    set.slots[index].access_ts = cache.totalCycle;
}

void discard(Cache &cache, Slot &slot) {
    if (slot.dirty) {
        cache.totalCycle += cache.sizeSlot * 25;
        slot.dirty = false;
    }
}