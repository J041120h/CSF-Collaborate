For MS1, we discussed together about structure of our cache simulator and write collaboratively
