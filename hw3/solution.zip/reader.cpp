#include <iostream>
int reader() {
    return 0;
}
